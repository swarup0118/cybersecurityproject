import cv2
import numpy as np
import getpass

# Function to convert binary to text
def binary_to_text(binary):
    chars = [binary[i:i+8] for i in range(0, len(binary), 8)]
    return ''.join(chr(int(char, 2)) for char in chars)

# Function to retrieve text from an image
def retrieve_data(image_path, password):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Image not found!")
    
    binary_data = ""
    for row in img:
        for pixel in row:
            for channel in range(3):
                binary_data += str(pixel[channel] & 1)
    
    # Extract binary message
    binary_message = binary_data.split('1111111111111110')[0]  # Remove end delimiter
    extracted_text = binary_to_text(binary_message)
    
    if extracted_text.startswith(password):
        return extracted_text[len(password):]  # Remove password and return message
    else:
        raise ValueError("❌ Incorrect password! Access denied.")

# Decrypt the message
passwd_attempt = getpass.getpass("Enter passcode for decryption: ")
try:
    decrypted_msg = retrieve_data("stego_image.png", passwd_attempt)
    print("🔓 Decrypted message:", decrypted_msg)
except ValueError as e:
    print(e)
