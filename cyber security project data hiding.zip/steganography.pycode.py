import numpy as np
import getpass
import os

# Function to convert text to binary
def text_to_binary(text):
    return ''.join(format(ord(char), '08b') for char in text)

# Function to convert binary to text
def binary_to_text(binary):
    chars = [binary[i:i+8] for i in range(0, len(binary), 8)]
    return ''.join(chr(int(char, 2)) for char in chars)

# Function to hide text inside an image
def hide_data(image_path, message, password, output_path="stego_image.png"):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Image not found!")
    
    max_bytes = img.shape[0] * img.shape[1] * 3 // 8
    
    if len(message) > max_bytes:
        raise ValueError("Message too long to fit in the image!")
    
    binary_message = text_to_binary(password + message)  # Combine password with message
    binary_message += '1111111111111110'  # End delimiter
    
    data_index = 0
    for row in img:
        for pixel in row:
            for channel in range(3):
                if data_index < len(binary_message):
                    pixel[channel] = (pixel[channel] & ~1) | int(binary_message[data_index])
                    data_index += 1
    
    cv2.imwrite(output_path, img)
    print(f"✅ Message hidden successfully! Saved as '{output_path}'")

# Function to retrieve text from an image
def retrieve_data(image_path, password):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Image not found!")
    
    binary_data = ""
    for row in img:
        for pixel in row:
            for channel in range(3):
                binary_data += str(pixel[channel] & 1)
    
    # Extract binary message
    binary_message = binary_data.split('1111111111111110')[0]  # Remove end delimiter
    extracted_text = binary_to_text(binary_message)
    
    if extracted_text.startswith(password):
        return extracted_text[len(password):]  # Remove password and return message
    else:
        raise ValueError("❌ Incorrect password! Access denied.")

# User input
image_file = "mypic.jpg"  # Change this to your actual image file
msg = input("Enter secret message: ")
passwd = getpass.getpass("Enter a passcode: ")

# Encrypt and save image
hide_data(image_file, msg, passwd)

# Decrypt the message
passwd_attempt = getpass.getpass("Enter passcode for decryption: ")
try:
    decrypted_msg = retrieve_data("stego_image.png", passwd_attempt)
    print("🔓 Decrypted message:", decrypted_msg)
except ValueError as e:
    print(e)