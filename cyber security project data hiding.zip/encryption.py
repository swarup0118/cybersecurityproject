import cv2
import numpy as np
import getpass

# Function to convert text to binary
def text_to_binary(text):
    return ''.join(format(ord(char), '08b') for char in text)

# Function to hide text inside an image
def hide_data(image_path, message, password, output_path="stego_image.png"):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Image not found!")
    
    max_bytes = img.shape[0] * img.shape[1] * 3 // 8
    
    if len(message) > max_bytes:
        raise ValueError("Message too long to fit in the image!")
    
    binary_message = text_to_binary(password + message)  # Combine password with message
    binary_message += '1111111111111110'  # End delimiter
    
    data_index = 0
    for row in img:
        for pixel in row:
            for channel in range(3):
                if data_index < len(binary_message):
                    pixel[channel] = (pixel[channel] & ~1) | int(binary_message[data_index])
                    data_index += 1
    
    cv2.imwrite(output_path, img)
    print(f"✅ Message hidden successfully! Saved as '{output_path}'")

# User input
image_file = "mypic.jpg"  # Change this to your actual image file
msg = input("Enter secret message: ")
passwd = getpass.getpass("Enter a passcode: ")

# Encrypt and save image
hide_data(image_file, msg, passwd)
